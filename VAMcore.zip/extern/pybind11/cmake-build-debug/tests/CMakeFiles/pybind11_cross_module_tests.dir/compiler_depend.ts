# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for pybind11_cross_module_tests.
