# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for cross_module_gil_utils.
